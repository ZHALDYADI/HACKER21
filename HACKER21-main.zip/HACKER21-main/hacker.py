print(*jangan lupa subcribe*)
